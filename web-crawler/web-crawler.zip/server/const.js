module.exports = {
    //虎扑
    HPURL:'https://bbs.hupu.com/selfie-',

    //360cp
    CP_HX:'http://cpjh360.com/txt/hongxiu.txt',
    CP_LY:'http://cpjh360.com/txt/langya.txt',
    CP_QK:'http://cpjh360.com/txt/qiankun.txt'


}
