exports.getladiesInfo = function(req,res){

    response.send(res, {
        state: 1,
        msg: '存储权限数据出错'
    }, '操作mongodb: 存储权限数据出错');
    return;
    // var app = req.query.app,
    //     mod = req.query.mod
}